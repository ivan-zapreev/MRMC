#include <stdio.h>
#include <malloc.h>
int read_tra_file(char *infile, char *outfile)
{
        FILE *ip, *op;
        char  s[1024],states[6],transitions[11];
	int size, row, col, nnz;
	double val = 0.0;
	ip = fopen(infile, "r");
	op = fopen(outfile, "w");
	
	if(ip==NULL||op==NULL) return 0;
	if(fgets( s, 1024, ip )!=NULL)
	{
		sscanf( s, "%s%d", states, &size);
		if(fgets( s, 1024, ip )!=NULL)
		{
			sscanf( s, "%s%d", transitions, &nnz);
			fprintf( op, "%s %d\n", states, size);
			fprintf( op, "%s %d\n", transitions, nnz);
			while (NULL != fgets( s, 1024, ip ))
			{
				sscanf( s, "%d%d%lf\n", &row, &col, &val );
				fprintf(op, "%d %d %lf\n", row+1, col+1, val);
			}
    		}	      
	}	      
    	(void)fclose(ip);
	(void)fclose(op);
	return 1;
}

main(int argc, char **argv)
{
	if(argc==3)
		printf("done: %d\n",read_tra_file(argv[1], argv[2]));
	else
		printf("FORMAT: <infile> <outfile> \n");
}
