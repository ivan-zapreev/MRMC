#include<stdio.h>
#include<malloc.h>
unsigned int read_file(int size, int k, char *infile, char *outfile)
{
        FILE *p;
        char  s[1024];
	int *minimum = (int *)calloc(size, sizeof(int)), validp=0, i;
	int state, left_n, left, right_n, right, r, line, line_n, Toleft, Toleft_n, Toright, Toright_n;
	for(i=0;i<size;i++)
		minimum[i]=0;
	p = fopen(infile, "r");
	if(p==NULL) return 0;
    	while (NULL != fgets( s, 1024, p ))
 	{
sscanf( s, "%d:(%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d)", &state, &left_n, &left, &right_n, &right, &r, &line, &line_n, &Toleft, &Toleft_n, &Toright, &Toright_n );
if((left_n>=k&&Toleft_n)||(right_n>=k & Toright_n)||((left_n+right_n)>=k&&Toleft_n&&line_n&&Toright_n))
	minimum[state] = 1;
    	}
    	(void)fclose(p);
    	
	p = fopen(outfile, "w");
	fprintf(p, "#DECLARATION\n");
	fprintf(p, "minimum\n");
	fprintf(p, "#END\n");
	for(i=0;i<size;i++)
		if(minimum[i]==1)
			fprintf(p, "%d  minimum\n", i+1);
	(void)fclose(p);
	return size;
}

main(int argc, char **argv)
{
	if(argc==5)
		printf("done: %d\n",read_file(atoi(argv[1]), atoi(argv[2]), argv[3], argv[4]));
	else
		printf("FORMAT: size k <infile> <outfile> \n");
}
